<?php
//Config Database
define('DB_HOST', 'localhost');
define('DB_USER', 'YOURDBUSER');
define('DB_PASS', 'YOURPASS');
define('DB_NAME', 'YOURDBNAME');
define('TIMEZONE', 'Asia/Kolkata');
define('ENCRYPTION_KEY', '25c7aa4e16660d8a972c9953239c055b');
