<?php
$lang["get_your_social_accounts_followers_and_likes_at_one_place_instantly"] = "Get Your Social Account's Followers And Likes At One Place, Instantly";
$lang["what_people_say_about_us"] = "What People Say About Us";
$lang["our_service_has_an_extensive_customer_roster_built_on_years_worth_of_trust_read_what_our_buyers_think_about_our_range_of_service"] = "Our service has an extensive customer roster built on years’ worth of trust. Read what our buyers think about our range of service.";
$lang["client_one"] = "John Smith";
$lang["client_one_jobname"] = "Youtuber";
$lang["client_one_comment"] = "After trying several websites who claim to have 'fast delivery', I'm glad I finally found this service. They literally started delivering 5 seconds after my payment!";
$lang["client_two"] = "Keith Irvine";
$lang["client_two_jobname"] = "Instagram Model";
$lang["client_two_comment"] = "I cannot stress enough how happy I am with the service that I received. Thanks to all of you, my Instagram account is surging with activity! You’ve not only earned yourself a loyal customer, but a friend for life.";
$lang["client_three"] = "Sara-Jade Bevis";
$lang["client_three_jobname"] = "Bloger";
$lang["client_three_comment"] = "Wow! This is amazing, i have been purchasing Instagram Likes for over a year and never got a delay! ? did a great job always";
$lang["we_have_several_services_that_you_can_opt_for_backed_by_our_comprehensive_guarantee_click_the_button_below_to_find_out_more"] = "We have several services that you can opt for backed by our comprehensive guarantee – click the button below to find out more.";

